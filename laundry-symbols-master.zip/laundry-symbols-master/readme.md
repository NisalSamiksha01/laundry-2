<h3 align="center">
  <code>laundry-symbols</code> (<a href="//github.com/tvler/laundry-symbols/releases/latest">zip file</a>)
</h3>
<p align="center">
  Every laundry symbol as a 24x24 SVG
</p>
<p align="center">
  <img src="symbols/machine-wash-normal.svg" />
  &nbsp;&nbsp;
  <img src="symbols/machine-wash-cold.svg" />
  &nbsp;&nbsp;
  <img src="symbols/machine-wash-warm.svg" />
  &nbsp;&nbsp;
  <img src="symbols/machine-wash-hot.svg" />
  &nbsp;&nbsp;
  <img src="symbols/machine-wash-very-hot.svg" />
  &nbsp;&nbsp;
  <img src="symbols/hand-wash.svg" />
  <br /><br />
  <img src="symbols/machine-wash-permanent-press.svg" />
  &nbsp;&nbsp;
  <img src="symbols/machine-wash-delicate.svg" />
  &nbsp;&nbsp;
  <img src="symbols/do-not-machine-wash.svg" />
  &nbsp;&nbsp;
  <img src="symbols/bleach.svg" />
  &nbsp;&nbsp;
  <img src="symbols/bleach-non-chlorine.svg" />
  &nbsp;&nbsp;
  <img src="symbols/do-not-bleach.svg" />
  <br /><br />
  <img src="symbols/tumble-dry-normal.svg" />
  &nbsp;&nbsp;
  <img src="symbols/tumble-dry-low.svg" />
  &nbsp;&nbsp;
  <img src="symbols/tumble-dry-medium.svg" />
  &nbsp;&nbsp;
  <img src="symbols/tumble-dry-high.svg" />
  &nbsp;&nbsp;
  <img src="symbols/tumble-dry-permanent-press.svg" />
  &nbsp;&nbsp;
  <img src="symbols/tumble-dry-delicate.svg" />
  <br /><br />
  <img src="symbols/tumble-dry-no-heat.svg" />
  &nbsp;&nbsp;
  <img src="symbols/do-not-tumble-dry.svg" />
  &nbsp;&nbsp;
  <img src="symbols/hang-dry.svg" />
  &nbsp;&nbsp;
  <img src="symbols/drip-dry.svg" />
  &nbsp;&nbsp;
  <img src="symbols/dry-flat.svg" />
  &nbsp;&nbsp;
  <img src="symbols/dry-in-shade.svg" />
  <br /><br />
  <img src="symbols/do-not-dry.svg" />
  &nbsp;&nbsp;
  <img src="symbols/iron-low.svg" />
  &nbsp;&nbsp;
  <img src="symbols/iron-medium.svg" />
  &nbsp;&nbsp;
  <img src="symbols/iron-high.svg" />
  &nbsp;&nbsp;
  <img src="symbols/iron-no-steam.svg" />
  &nbsp;&nbsp;
  <img src="symbols/do-not-iron.svg" />
  <br /><br />
  <img src="symbols/dry-clean.svg" />
  &nbsp;&nbsp;
  <img src="symbols/dry-clean-any-solvent.svg" />
  &nbsp;&nbsp;
  <img src="symbols/dry-clean-hydrocarbon-solvent.svg" />
  &nbsp;&nbsp;
  <img src="symbols/dry-clean-tetrachloroethylene-solvent.svg" />
  &nbsp;&nbsp;
  <img src="symbols/professional-wet-cleaning.svg" />
  &nbsp;&nbsp;
  <img src="symbols/do-not-dry-clean.svg" />
  <br /><br />
  <img src="symbols/do-not-wring.svg" />
</p>
